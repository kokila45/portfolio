// Portfolio data + render
const projects = [
  {
    no: "01",
    title: "InternGuardAPI",
    subtitle: "Automated Internship Fraud Detection Framework",
    stack: ["Python", "BERT", "NLP", "REST API"],
    description:
      "BERT-based verification API that flags fraudulent internship postings for job service providers. Combines NLP classification with a risk-scoring layer to automate verification, approval, and reporting workflows end-to-end.",
    links: [
      { label: "GitHub", href: "https://github.com/kokila-m/internguard-api" },
      { label: "Case study", href: "#" },
    ],
  },
  {
    no: "02",
    title: "Style-Modulated Enhanced GAN",
    subtitle: "Generative Design for Synthetic Imagery",
    stack: ["Python", "GAN", "Deep Learning"],
    description:
      "Enhanced GAN architecture with style modulation for high-quality, consistent image generation — improving training stability and visual fidelity for AI-driven design applications.",
    links: [
      { label: "GitHub", href: "https://github.com/kokila-m/style-gan" },
      { label: "Paper notes", href: "#" },
    ],
  },
  {
    no: "03",
    title: "Weather Forecast Web App",
    subtitle: "Responsive client for real-time conditions",
    stack: ["HTML", "CSS", "JavaScript", "REST"],
    description:
      "Responsive weather app consuming a public API to surface real-time temperature, humidity, wind, and conditions by city — with input validation and graceful error handling.",
    links: [
      { label: "Live demo", href: "#" },
      { label: "GitHub", href: "https://github.com/kokila-m/weather-app" },
    ],
  },
];

const education = [
  { degree: "MCA", inst: "Nandha Engineering College", score: "84%", year: "2026" },
  { degree: "B.Sc Computer Science", inst: "Nandha Arts and Science College", score: "82.75%", year: "2024" },
  { degree: "HSC", inst: "KVKN Matric Hr. Sec. School", score: "74.69%", year: "2021" },
  { degree: "SSLC", inst: "Government Hr. Sec. School, Singanallur", score: "61%", year: "2019" },
];

const strengths = ["Self-motivated", "Quick learner", "Adaptable", "Responsible", "Positive attitude", "Strong work ethic"];

const arrow = `<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 17 17 7"/><path d="M8 7h9v9"/></svg>`;

// Render projects
document.getElementById("projects").innerHTML = projects.map(p => `
  <article class="project">
    <div class="proj-no">${p.no}</div>
    <div>
      <h3 class="proj-title">${p.title}</h3>
      <p class="proj-sub">${p.subtitle}</p>
      <div class="tags">${p.stack.map(t => `<span class="tag">${t}</span>`).join("")}</div>
    </div>
    <div class="proj-body">
      <p>${p.description}</p>
      <div class="proj-links">
        ${p.links.map(l => `<a href="${l.href}" class="proj-link" target="_blank" rel="noopener noreferrer">${l.label} ${arrow}</a>`).join("")}
      </div>
    </div>
  </article>
`).join("");

// Render education
document.getElementById("education-list").innerHTML = education.map(e => `
  <li>
    <div class="edu-row">
      <span class="edu-degree">${e.degree}</span>
      <span class="edu-inst">${e.inst}</span>
      <span class="edu-score">${e.score}</span>
      <span class="edu-year">${e.year}</span>
    </div>
  </li>
`).join("");

// Render strengths
document.getElementById("strengths").innerHTML = strengths.map(s => `<li>${s}</li>`).join("");

// Footer year
document.getElementById("year").textContent = new Date().getFullYear();

// Smooth nav highlight on scroll (lightweight)
const navLinks = document.querySelectorAll(".nav a");
const sections = [...navLinks].map(a => document.querySelector(a.getAttribute("href")));
window.addEventListener("scroll", () => {
  const y = window.scrollY + 120;
  sections.forEach((sec, i) => {
    if (!sec) return;
    const top = sec.offsetTop, bot = top + sec.offsetHeight;
    navLinks[i].style.color = (y >= top && y < bot) ? "var(--clay)" : "";
  });
});
